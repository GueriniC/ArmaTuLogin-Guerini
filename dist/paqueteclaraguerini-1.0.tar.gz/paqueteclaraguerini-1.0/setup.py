from setuptools import setup, find_packages

setup(
    name="paqueteClaraGuerini", 
    version="1.0",  
    packages=find_packages(), 
    description="Entrega para CoderHouse", 
)
def mostrar_bienvenida():
    print("Bienvenido/a!")
